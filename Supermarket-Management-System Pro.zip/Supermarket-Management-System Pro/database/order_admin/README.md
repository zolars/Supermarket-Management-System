# README

### 路径

.../database/order_admin/

### {shop_id}\_all.txt

n行

7列

订单编号 | 顾客ID | 购买时间 | 商品ID | 购买数量 | 单价 | 总价

### {shop_id}\_goods.txt

n行

4列

商品ID | 销量 | 营业额 | 利润

### {shop_id}\_consumer.txt

n行

3列

顾客ID | 商品ID | 购买数
