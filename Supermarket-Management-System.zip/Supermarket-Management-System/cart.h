/************************************************

Name:
  cart.h
Author:
  - 刘育成
  - 王楠鑫
Date:
  2017-09-15
Language:
  C
Features:

************************************************/

#ifndef _CART_H_ // 防止重复调用
#define _CART_H_

extern int cart_choose();

extern int cart(char user_id[30]);

extern int cart_main(char user_id[30]);

#endif /*_CART_H_*/
