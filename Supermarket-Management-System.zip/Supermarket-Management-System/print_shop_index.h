/************************************************

Name:
  print_shop_index.h
Author:
  王楠鑫
Date:
  2017-09-15
Language:
  C
Features:

************************************************/

#ifndef _PRINT_SHOP_INDEX_H_ // 防止重复调用
#define _PRINT_SHOP_INDEX_H_

extern int print_shop_index_main(char user_id[30]);

#endif /*_PRINT_SHOP_INDEX_H_*/
