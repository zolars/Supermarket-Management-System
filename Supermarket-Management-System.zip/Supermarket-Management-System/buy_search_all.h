/************************************************

Name:
  buy_search_all.h
Author:
  董泽元
Date:
  2017-09-15
Language:
  C
Features:

************************************************/

#ifndef _BUY_SEARCH_ALL_H_ // 防止重复调用
#define _BUY_SEARCH_ALL_H_

extern int buy_search_all_choose();

extern int buy_search_all(char user_id[30]);

#endif /*_BUY_SEARCH_ALL_H_*/
