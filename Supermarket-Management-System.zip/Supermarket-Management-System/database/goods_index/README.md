# README

### 路径

.../database/goods_index/

### 文件名

{goods_id}.txt

### 存放数据

n行

8列

超市ID | 单价 | 进价 | 销量 | 库存 | 折扣价格 | 折扣开始时间 |折扣结束时间
