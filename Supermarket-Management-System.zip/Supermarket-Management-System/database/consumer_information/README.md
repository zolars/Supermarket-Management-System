# README

### 路径

.../database/consumer_information/

### 文件名

{consumer_id}.txt

### 存放数据

1行

7列

顾客姓名 | 性别(男性 : 1, 女性: 0) | 手机号 | 密码 | 邮箱 | 地址 | 余额
