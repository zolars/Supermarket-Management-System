# README

### 路径

.../database/order_consumer/

### {consumer_id}.txt

n行

6列

订单编号 | 订单时间 | 商品ID | 购买数量 | 单价 | 总价
