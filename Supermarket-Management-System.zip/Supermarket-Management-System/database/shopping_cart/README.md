# README

### 路径

.../database/shopping_cart/

### {consumer_id}.txt

n行

3列

商品ID | 商店ID | 打算购买数量
