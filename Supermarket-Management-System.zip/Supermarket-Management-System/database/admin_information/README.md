# README

### 路径

.../database/admin_information/

### 文件名

{admin_id}.txt

### 存放数据

1行

4列

超市名 | 管理员姓名 | 邮箱 | 密码
