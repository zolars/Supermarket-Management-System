# README

### 路径

.../database/shop_index/

### {admin_id}.txt

n行

8列

货物ID | 单价 | 进价 | 销量 | 库存 | 折扣价格 | 折扣开始时间 |折扣结束时间
